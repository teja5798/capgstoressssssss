package com.capgemini.capgstores.service;

import java.util.List;

import com.capgemini.capgstores.model.Invoice;

public interface InvoiceService {

	

	public List<Invoice> getInvoiceFromOrderId(int productid);

		

	
	}
